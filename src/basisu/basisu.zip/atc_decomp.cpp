#include "atc_decomp.h"

typedef struct {
	uint8_t r, g, b, a;
} rgba;

void unpack_atc(const uint8_t* pBytes, uint8_t* pPixels)
{
    const uint16_t color0 = pBytes[0] | (pBytes[1] << 8U);
    const uint16_t color1 = pBytes[2] | (pBytes[3] << 8U);
    uint32_t sels = pBytes[4] | (pBytes[5] << 8U) | (pBytes[6] << 16U) | (pBytes[7] << 24U);

    const bool mode = (color0 & 0x8000) != 0;

    rgba c[4];

    
    c[0].set((color0 >> 10) & 31, (color0 >> 5) & 31, color0 & 31, 255);
    c[0].r = (c[0].r << 3) | (c[0].r >> 2);
    c[0].g = (c[0].g << 3) | (c[0].g >> 2);
    c[0].b = (c[0].b << 3) | (c[0].b >> 2);
    /*
    c[0] = (color0 >>10) & 31;
    c[1] = (color0 >> 5) & 31;
    c[2] = color0 & 31;
    c[3] = 255;
    c[1] = (c[1] << 3) | (c[1] >> 2);
    c[2] = (c[2] << 3) | (c[2] >> 2);
    c[3] = (c[3] << 3) | (c[3] >> 2);
    */
    c[3].set((color1 >> 11) & 31, (color1 >> 5) & 63, color1 & 31, 255);
    c[3].r = (c[3].r << 3) | (c[3].r >> 2);
    c[3].g = (c[3].g << 2) | (c[3].g >> 4);
    c[3].b = (c[3].b << 3) | (c[3].b >> 2);
    /*
    c[12] = (color1 >>11) & 31;
    c[13] = (color1 >> 5) & 63;
    c[14] = color1 & 31;
    c[15] = 255;
    c[12] = (c[12] << 3) | (c[12] >> 2);
    c[13] = (c[13] << 2) | (c[13] >> 4);
    c[14] = (c[14] << 3) | (c[14] >> 2);
    */

    if (mode)
    {
        c[1].set(std::max(0, c[0].r - (c[3].r >> 2)), std::max(0, c[0].g - (c[3].g >> 2)), std::max(0, c[0].b - (c[3].b >> 2)), 255);
        c[2] = c[0];
        c[0].set(0, 0, 0, 255);
        /*
        c[4] = std::max(0, c[1] - (c[12] >> 2));
        c[5] = std::max(0, c[2] - (c[13] >> 2));
        c[6] = std::max(0, c[3] - (c[14] >> 2));
        c[7] = 255;
        c[8] = c[0];
        c[9] = c[1];
        c[10] = c[2];
        c[11] = c[3];
        c[0] = 0;
        c[1] = 0;
        c[2] = 0;
        c[3] = 255;
        */
    }
    else
    {
        c[1].r = (c[0].r * 5 + c[3].r * 3) >> 3;
        c[1].g = (c[0].g * 5 + c[3].g * 3) >> 3;
        c[1].b = (c[0].b * 5 + c[3].b * 3) >> 3;
        /*
        c[4] = (c[0]*5 + c[12]*3)>>3;
        c[5] = (c[1]*5 + c[13]*3)>>3;
        c[6] = (c[2]*5 + c[14]*3)>>3;
       */
        c[2].r = (c[0].r * 3 + c[3].r * 5) >> 3;
        c[2].g = (c[0].g * 3 + c[3].g * 5) >> 3;
        c[2].b = (c[0].b * 3 + c[3].b * 5) >> 3;
        /*
        c[8] = (c[0]*3 + c[12]*5)>>3;
        c[9] = (c[1]*3 + c[13]*5)>>3;
        c[10] = (c[2]*3 + c[14]*5)>>3;
        */
    }

    for (uint32_t i = 0; i < 16; i++)
    {
        const uint32_t s = sels & 3;
        
        //pPixels[i] = c[s];
        memcpy(pPixels+i*4, c+s*4,4);
                      
        sels >>= 2;
    }
}