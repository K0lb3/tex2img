#include <stdint.h>
#include <algorithm>
#include <cstring>

void unpack_atc(const uint8_t* pBytes, uint8_t* pPixels);